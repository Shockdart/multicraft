<?php
/**
 *
 *   Copyright © 2010-2016 by xhost.ch GmbH
 *
 *   All rights reserved.
 *
 **/
?>
<?php $this->renderPartial('//layouts/components/head1'); ?>
    <div id="watermark-logo"></div>
    <div id="mini">
        
        <?php $this->renderPartial('//layouts/components/navigation1'); ?>

        <div class="row" id="content"><?php echo $content; ?></div>
    </div>
    <br><br><br><br><br><br><br><br><Br><br><br><br>
<?php $this->renderPartial('//layouts/components/foot1'); ?>
