
</div>
<script src="<?php echo Theme::js('bootstrap.min.js') ?>"></script>
<script src="<?php echo Theme::js('multicraft.js') ?>"></script>

	 </section>


    <footer id="footer">
        <div class="containerx">
            <div class="rowx">
                <div class="colx-sm-6">
                    &copy; 2017 YourCompany - Premium UK Web Hosting <a href="https://webserviceswales.com">https://webserviceswales.com</a>
                </div>
                <div class="colx-sm-6">
                    <ul class="social-icons">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li> 
                        <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                        <li><a href="#"><i class="fa fa-github"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->


    <script src="<?php echo Theme::css('') ?>/files/js/bootstrap.js"></script> 
    <script src="<?php echo Theme::css('') ?>/files/js/mousescroll.js"></script>
    <script src="<?php echo Theme::css('') ?>/files/js/smoothscroll.js"></script>
    <script src="<?php echo Theme::css('') ?>/files/js/custom-scripts.js"></script>
    
</body>
</html>
