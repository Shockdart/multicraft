<?php
/**
 *
 *   Copyright © 2010-2016 by xhost.ch GmbH
 *
 *   All rights reserved.
 *
 **/
?>
<!doctype html>
<html lang="en">
<!--
 -
 -   Copyright © 2010-2016 by xhost.ch GmbH
 -
 -   All rights reserved.
 -
 -->
<head>
    <meta content="initial-scale=1.0, width=device-width, user-scalable=yes" name="viewport">
    <meta content="yes" name="apple-mobile-web-app-capable">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="language" content="en" />
    <link rev="made" href="mailto:info@multicraft.org">
    <meta name="description" content="Multicraft: The Minecraft server control panel">
    <meta name="keywords" content="Multicraft, Minecraft, server, management, control panel, hosting">
    <meta name="author" content="xhost.ch GmbH">
    <meta charset="UTF-8" />
    <link rel="shortcut icon" href="<?php echo  Yii::app()->request->baseUrl; ?>/favicon.ico" />

    <link rel="stylesheet" type="text/css" href="<?php echo Theme::css('style.css') ?>" media="screen, projection" />

    <title><?php echo CHtml::encode($this->pageTitle); ?></title>
    
    <link href="<?php echo Theme::css('') ?>/files/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo Theme::css('') ?>/files/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo Theme::css('') ?>/files/css/animate.min.css" rel="stylesheet"> 
    <link href="<?php echo Theme::css('') ?>/files/css/prettyPhoto.css" rel="stylesheet">
    <link href="<?php echo Theme::css('') ?>/files/css/styles.css" rel="stylesheet"> 
    <link rel="shortcut icon" href="<?php echo Theme::css('') ?>/files/images/ico/favicon.ico">    
    
</head>

<body id="home">

    <header id="headerx">
        <nav id="main-nav" class="navxbar navxbar-default navxbar-fixed-top" role="banner">
            <div class="containerx">
                <div class="navxbar-header">
                    <button type="button" class="navxbar-toggle" data-toggle="collapsex" data-target=".navxbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navxbar-brand" href="index.php"><img src="<?php echo Theme::css('') ?>/files/images/logo.png" alt="logo"></a>
                </div>
				
                <div class="collapsex navxbar-collapse navxbar-right">
                    <ul class="navx navxbar-nav">
                        <li class="scroll active"><a href="">Home</a></li> 
						            <li class="scroll"><a href="">Features</a></li>
                        <li class="scroll"><a href="">Services</a></li>
                        <li class="scroll"><a href="">About</a></li> 
                        <li class="scroll"><a href="">Pricing</a></li>
                        <li class="scroll"><a href="">Team</a></li>
                        <li class="scroll"><a href="">Contact</a></li>                        
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->
    </header><!--/header-->

  
     <section id="features">
